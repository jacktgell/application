import sys
from file_processing import read_input_file
from search_matches import find_matches, format_output


def main(file_path):
    # Read the input file and extract source_text and search_term
    source_text, search_term = read_input_file(file_path)

    # Find the lines in the source_text that match the search_term
    matches = find_matches(source_text, search_term)

    # Format the output lines
    formatted_output = format_output(matches)

    # Print the formatted output lines
    for line in formatted_output:
        print(line)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
    else:
        file_path = "default_input_file.txt"  # Replace with the path to your default input file

    main(file_path)
