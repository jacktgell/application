import unittest
from file_processing import read_input_file, extract_words
from search_matches import find_matches, format_output


class TestMain(unittest.TestCase):

    def test_read_input_file(self):
        source_text, search_term = read_input_file('test_input.txt')
        expected_source_text = [
            ['cat', 'sees', 'me'],
            ['mary', 'likes', 'trees'],
            ['up', 'the', 'hill']
        ]
        expected_search_term = 'ee'
        self.assertEqual(source_text, expected_source_text)
        self.assertEqual(search_term, expected_search_term)

    def test_extract_words(self):
        line = '908^)-234 923this-++-23is./<.";][}"another-=&^5'
        expected_words = ['this', 'is', 'another']
        self.assertEqual(extract_words(line), expected_words)

    def test_find_matches(self):
        source_text = [
            ['cat', 'sees', 'me'],
            ['mary', 'likes', 'trees'],
            ['up', 'the', 'hill']
        ]
        search_term = 'ee'
        expected_matches = [
            ['cat', 'sees', 'me'],
            ['mary', 'likes', 'trees']
        ]
        self.assertEqual(find_matches(source_text, search_term), expected_matches)

    def test_format_output(self):
        matches = [
            ['cat', 'sees', 'me'],
            ['mary', 'likes', 'trees']
        ]
        expected_output = [
            '[cat sees me]',
            '[mary likes trees]'
        ]
        self.assertEqual(format_output(matches), expected_output)


if __name__ == '__main__':
    unittest.main()
