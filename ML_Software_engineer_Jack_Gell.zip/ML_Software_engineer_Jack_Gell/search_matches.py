def find_matches(source_text, search_term):
    """
    Find matching lines in the source_text based on the search_term.

    Args:
        source_text (list): A list of lists of words representing the source text.
        search_term (str): The search term as a string.

    Returns:
        list: A list of lists of words representing the matching lines.
    """
    matches = []
    for line in source_text:
        if any(search_term in word for word in line):
            matches.append(line)
    return matches


def format_output(matches):
    """
    Format the output lines according to the specified format.

    Args:
        matches (list): A list of lists of words representing the matching lines.

    Returns:
        list: A list of strings representing the formatted output lines.
    """
    formatted_output = []
    for match in matches:
        formatted_line = '[' + ' '.join(match) + ']'
        formatted_output.append(formatted_line)
    return formatted_output
