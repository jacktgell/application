import re
import sys


def read_input_file(file_path):
    """
    Read the input file and return the source_text and search_term.

    Args:
        file_path (str): The path to the input file.

    Returns:
        tuple: A tuple containing the source_text as a list of lists of words, and the search_term as a string.
    """

    try:
        with open(file_path, 'r') as f:
            lines = f.readlines()
            search_term = lines.pop().strip()
            source_text = [extract_words(line.strip()) for line in lines]
        return source_text, search_term
    except FileNotFoundError:
        print(f"Error: The file {file_path} was not found.")
        sys.exit(1)


def extract_words(line):
    """
    Extract words from a line using regular expressions.

    Args:
        line (str): A string representing a line of text.

    Returns:
        list: A list of words extracted from the line.
    """
    return re.findall(r'\b\w+\b', line)
